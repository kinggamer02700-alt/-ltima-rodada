ULTIMA RODADA — PROJETO ANDROID

O projeto transforma o jogo HTML em um aplicativo Android usando WebView.
Inclui ícone personalizado, nome do app e orientação horizontal em tela cheia.
A mesa mostra os quatro jogadores nas posições: baixo, esquerda, cima e direita.
Cada jogador começa com 3 vidas.

COMO GERAR O APK (NO COMPUTADOR)
1. Instale o Android Studio em um computador Windows, macOS ou Linux.
2. Extraia este ZIP para uma pasta.
3. Abra o Android Studio e escolha Open. Selecione a pasta UltimaRodada-Android (a pasta que contém settings.gradle).
4. Aguarde o Android Studio sincronizar o Gradle e instalar os componentes do Android SDK solicitados.
5. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, clique em locate no aviso ou procure por:
   app/build/outputs/apk/debug/app-debug.apk

PARA INSTALAR NO CELULAR
Copie app-debug.apk para o celular, abra o arquivo e autorize a instalação desta fonte se o Android pedir.

OBSERVAÇÕES
- Android Studio é um programa para computador; não é instalado no Moto G35.
- Este ZIP é o projeto-fonte, não é o APK pronto.
- É necessário internet na primeira sincronização para baixar Gradle/Android Gradle Plugin/SDK.
- O aplicativo usa o jogo local incluído em app/src/main/assets/index.html.

Atualização visual: banner Última Rodada com ilustração .38 na tela inicial; ícones do aplicativo atualizados.
